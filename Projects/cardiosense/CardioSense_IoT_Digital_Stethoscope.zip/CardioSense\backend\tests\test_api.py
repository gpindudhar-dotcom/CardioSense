"""Backend API tests."""

from __future__ import annotations

import math
import struct
import sys
from pathlib import Path

import numpy as np
import pytest
from fastapi.testclient import TestClient

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "backend"))

from app.main import app
from app.websocket import PACKET_MAGIC, hub


@pytest.fixture()
def client(tmp_path, monkeypatch):
    db_path = tmp_path / "test.db"
    rec_dir = tmp_path / "recordings"
    rec_dir.mkdir()
    monkeypatch.setenv("DATABASE_URL", f"sqlite:///{db_path.as_posix()}")
    monkeypatch.setenv("RECORDINGS_DIR", str(rec_dir))

    # Re-init engine/db for test isolation
    from app import database
    from app.models import Base

    database.engine = database.create_db_engine()
    database.SessionLocal.configure(bind=database.engine)
    Base.metadata.drop_all(bind=database.engine)
    Base.metadata.create_all(bind=database.engine)

    hub.state.packets_received = 0
    hub.state.connected = False
    with TestClient(app) as c:
        yield c


def test_health(client):
    r = client.get("/health")
    assert r.status_code == 200
    body = r.json()
    assert body["status"] == "ok"
    assert "not a medical" in body["notice"].lower()


def test_device_status(client):
    r = client.get("/api/device/status")
    assert r.status_code == 200
    assert "signal_quality" in r.json()


def test_recordings_crud(client):
    sr = 4000
    t = np.arange(0, 1.0, 1 / sr)
    samples = (100 * np.sin(2 * np.pi * 80 * t)).tolist()
    created = client.post(
        "/api/recordings",
        json={
            "device_id": "test-device",
            "sample_rate": sr,
            "samples": samples,
            "signal_quality": "Fair",
        },
    )
    assert created.status_code == 200, created.text
    rec = created.json()
    rid = rec["id"]

    listed = client.get("/api/recordings")
    assert listed.status_code == 200
    assert any(x["id"] == rid for x in listed.json())

    got = client.get(f"/api/recordings/{rid}")
    assert got.status_code == 200

    dl = client.get(f"/api/recordings/{rid}/download")
    assert dl.status_code == 200
    assert dl.content[:4] == b"RIFF"

    deleted = client.delete(f"/api/recordings/{rid}")
    assert deleted.status_code == 200


def test_websocket_audio_packet(client):
    count = 64
    samples = [int(100 * math.sin(i / 5.0)) for i in range(count)]
    header = bytearray(32)
    struct.pack_into("<I", header, 0, PACKET_MAGIC)
    header[4] = 1
    header[5] = 1
    struct.pack_into("<H", header, 6, count)
    struct.pack_into("<I", header, 8, 7)
    struct.pack_into("<f", header, 12, 4000.0)
    struct.pack_into("<f", header, 16, 12.0)
    struct.pack_into("<f", header, 20, 40.0)
    struct.pack_into("<f", header, 24, float("nan"))
    header[28] = 2
    payload = bytes(header) + struct.pack(f"<{count}h", *samples)

    with client.websocket_connect("/ws/audio") as ws:
        hello = ws.receive_json()
        assert hello["type"] == "hello"
        _ = ws.receive_json()  # device_status
        ws.send_bytes(payload)
        msg = ws.receive_json()
        assert msg["type"] == "audio"
        assert len(msg["samples"]) == count
        assert msg["sequence"] == 7
