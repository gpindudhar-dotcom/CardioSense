"""
CardioSense FastAPI backend.

Educational prototype — not a medical diagnostic device.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import List, Optional

from dotenv import load_dotenv
from fastapi import Depends, FastAPI, HTTPException, WebSocket
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from pydantic import BaseModel
from sqlalchemy.orm import Session

from . import __version__
from .bridge import bridge
from .database import get_db, init_db, recordings_dir
from .models import DeviceStatus, HealthOut, Recording, RecordingCreate, RecordingOut
from .recordings import write_wav
from .signal_processing import assess_signal_quality, estimate_bpm, process_pipeline, spectrum
from .websocket import audio_websocket_endpoint, hub

load_dotenv()

NOTICE = "Educational prototype — not a medical diagnostic device."

app = FastAPI(
    title="CardioSense API",
    description=(
        "IoT digital stethoscope backend (educational prototype). "
        "Not for diagnosis, emergency use, or clinical decision-making."
    ),
    version=__version__,
)

origins = [
    o.strip()
    for o in os.getenv(
        "CORS_ORIGINS",
        "http://127.0.0.1:5173,http://localhost:5173",
    ).split(",")
    if o.strip()
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins or ["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
def on_startup() -> None:
    init_db()
    recordings_dir()


# Note: lifespan migration optional; on_event kept for broad FastAPI compatibility.


@app.get("/health", response_model=HealthOut)
def health() -> HealthOut:
    return HealthOut(
        status="ok",
        service="cardiosense-backend",
        version=__version__,
        notice=NOTICE,
    )


@app.get("/api/device/status", response_model=DeviceStatus)
def device_status() -> DeviceStatus:
    d = hub.state.to_dict()
    return DeviceStatus(**{k: v for k, v in d.items() if k in DeviceStatus.model_fields})


class DeviceConnectIn(BaseModel):
    host: str
    port: int = 81
    path: str = "/"


@app.post("/api/device/connect")
async def connect_device(body: DeviceConnectIn):
    """Connect backend bridge to ESP32 WebSocket server (default port 81)."""
    host = body.host.strip()
    if not host or len(host) > 253:
        raise HTTPException(status_code=400, detail="Invalid IP or hostname.")
    try:
        url = await bridge.start(host, body.port, body.path or "/")
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Unable to start bridge: {exc}") from exc
    return {"ok": True, "url": url, "active": bridge.active, "notice": NOTICE}


@app.post("/api/device/disconnect")
async def disconnect_device():
    await bridge.stop()
    hub.state.connected = False
    return {"ok": True, "active": False}


@app.websocket("/ws/audio")
async def ws_audio(websocket: WebSocket) -> None:
    await audio_websocket_endpoint(websocket)


def _recording_out(rec: Recording) -> RecordingOut:
    return RecordingOut(
        id=rec.id,
        created_at=rec.created_at,
        duration_sec=rec.duration_sec,
        sample_rate=rec.sample_rate,
        sample_count=rec.sample_count,
        device_id=rec.device_id,
        estimated_bpm=rec.estimated_bpm,
        signal_quality=rec.signal_quality,
        filename=rec.filename,
        notes=rec.notes,
        download_url=f"/api/recordings/{rec.id}/download",
    )


@app.post("/api/recordings", response_model=RecordingOut)
def create_recording(body: RecordingCreate, db: Session = Depends(get_db)) -> RecordingOut:
    if not body.samples:
        raise HTTPException(status_code=400, detail="No samples provided.")
    if body.sample_rate <= 0 or body.sample_rate > 96000:
        raise HTTPException(status_code=400, detail="Invalid sample rate.")

    try:
        quality = assess_signal_quality(body.samples, float(body.sample_rate))
        hr = estimate_bpm(body.samples, float(body.sample_rate))
        bpm = body.estimated_bpm if body.estimated_bpm is not None else (hr.bpm if hr.valid else None)
        qlabel = body.signal_quality if body.signal_quality not in ("Unknown", "") else quality.label

        # Temporary name; finalize after DB id
        tmp_name = f"tmp_{os.getpid()}.wav"
        meta = write_wav(recordings_dir() / tmp_name, body.samples, body.sample_rate)

        rec = Recording(
            duration_sec=meta["duration_sec"],
            sample_rate=body.sample_rate,
            sample_count=meta["sample_count"],
            device_id=body.device_id or "unknown",
            estimated_bpm=bpm,
            signal_quality=qlabel,
            filename=tmp_name,
            notes=body.notes,
        )
        db.add(rec)
        db.commit()
        db.refresh(rec)

        final_name = f"recording_{rec.id}.wav"
        final_path = recordings_dir() / final_name
        Path(meta["path"]).replace(final_path)
        rec.filename = final_name
        db.add(rec)
        db.commit()
        db.refresh(rec)
        return _recording_out(rec)
    except HTTPException:
        raise
    except Exception as exc:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Recording failure: {exc}") from exc


@app.get("/api/recordings", response_model=List[RecordingOut])
def list_recordings(db: Session = Depends(get_db)) -> List[RecordingOut]:
    rows = db.query(Recording).order_by(Recording.created_at.desc()).all()
    return [_recording_out(r) for r in rows]


@app.get("/api/recordings/{recording_id}", response_model=RecordingOut)
def get_recording(recording_id: int, db: Session = Depends(get_db)) -> RecordingOut:
    rec = db.get(Recording, recording_id)
    if not rec:
        raise HTTPException(status_code=404, detail="Recording not found.")
    return _recording_out(rec)


@app.get("/api/recordings/{recording_id}/download")
def download_recording(recording_id: int, db: Session = Depends(get_db)):
    rec = db.get(Recording, recording_id)
    if not rec:
        raise HTTPException(status_code=404, detail="Recording not found.")
    path = recordings_dir() / rec.filename
    if not path.exists():
        raise HTTPException(status_code=404, detail="WAV file missing on disk.")
    return FileResponse(path, media_type="audio/wav", filename=rec.filename)


@app.delete("/api/recordings/{recording_id}")
def delete_recording(recording_id: int, db: Session = Depends(get_db)):
    rec = db.get(Recording, recording_id)
    if not rec:
        raise HTTPException(status_code=404, detail="Recording not found.")
    path = recordings_dir() / rec.filename
    try:
        if path.exists():
            path.unlink()
        db.delete(rec)
        db.commit()
    except Exception as exc:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Delete failed: {exc}") from exc
    return {"ok": True, "id": recording_id}


@app.post("/api/analyze")
def analyze(body: RecordingCreate):
    if not body.samples:
        raise HTTPException(status_code=400, detail="No samples provided.")
    result = process_pipeline(body.samples, float(body.sample_rate))
    spec = spectrum(body.samples, float(body.sample_rate))
    return {"analysis": result, "spectrum": spec, "notice": NOTICE}


@app.exception_handler(Exception)
async def unhandled_exception_handler(request, exc):
    return JSONResponse(
        status_code=500,
        content={"detail": "Backend error", "message": str(exc), "notice": NOTICE},
    )
