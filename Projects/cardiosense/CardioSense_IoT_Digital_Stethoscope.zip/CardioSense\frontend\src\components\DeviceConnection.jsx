import React, { useState } from 'react';
import { connectDevice, disconnectDevice } from '../services/api';

function isValidIpOrHost(value) {
  if (!value || typeof value !== 'string') return false;
  const v = value.trim();
  if (v.length < 3 || v.length > 253) return false;
  const ipv4 = /^(?:\d{1,3}\.){3}\d{1,3}$/;
  const host = /^(?:[a-zA-Z0-9-]+\.)*[a-zA-Z0-9-]+$/;
  if (ipv4.test(v)) {
    return v.split('.').every((p) => {
      const n = Number(p);
      return n >= 0 && n <= 255;
    });
  }
  return host.test(v) || v === 'localhost';
}

export default function DeviceConnection({
  backendOnline,
  deviceOnline,
  deviceIp,
  onConnectBackend,
  onDisconnectBackend,
  onSetDeviceIp,
  error,
}) {
  const [ip, setIp] = useState(deviceIp || '');
  const [localError, setLocalError] = useState('');
  const [busy, setBusy] = useState(false);

  const saveAndBridge = async () => {
    if (!isValidIpOrHost(ip)) {
      setLocalError('Invalid IP or hostname. Example: 192.168.1.50');
      return;
    }
    setLocalError('');
    onSetDeviceIp(ip.trim());
    setBusy(true);
    try {
      await connectDevice(ip.trim(), 81);
    } catch (err) {
      setLocalError(err.message || 'Unable to bridge ESP32');
    } finally {
      setBusy(false);
    }
  };

  const stopBridge = async () => {
    setBusy(true);
    try {
      await disconnectDevice();
    } catch (err) {
      setLocalError(err.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="panel">
      <h3>Device Connection</h3>
      <p className="muted" style={{ marginTop: 0 }}>
        Connect the dashboard to the FastAPI backend, then enter the ESP32 IP so the backend can
        bridge WebSocket audio from firmware port 81.
      </p>
      <div className="row" style={{ marginBottom: '0.75rem' }}>
        <input
          type="text"
          value={ip}
          onChange={(e) => setIp(e.target.value)}
          placeholder="ESP32 IP (e.g. 192.168.1.50)"
          aria-label="ESP32 IP address"
        />
        <button type="button" className="btn btn-primary" onClick={saveAndBridge} disabled={busy || !backendOnline}>
          Connect ESP32
        </button>
        <button type="button" className="btn btn-secondary" onClick={stopBridge} disabled={busy}>
          Disconnect ESP32
        </button>
      </div>
      <div className="row">
        <button type="button" className="btn btn-secondary" onClick={onConnectBackend} disabled={backendOnline}>
          Connect Backend
        </button>
        <button type="button" className="btn btn-secondary" onClick={onDisconnectBackend} disabled={!backendOnline}>
          Disconnect Backend
        </button>
        <span className={`status-pill ${backendOnline ? 'online' : 'offline'}`}>
          <span className="dot" />
          Backend {backendOnline ? 'connected' : 'offline'}
        </span>
        <span className={`status-pill ${deviceOnline ? 'online' : 'offline'}`}>
          <span className="dot" />
          ESP32 {deviceOnline ? 'streaming' : 'unavailable'}
        </span>
      </div>
      {(localError || error) && (
        <div className="error-banner" style={{ marginTop: '0.75rem' }} role="alert">
          {localError || error}
        </div>
      )}
    </div>
  );
}
