import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import Header from './components/Header';
import DeviceConnection from './components/DeviceConnection';
import HeartRateCard from './components/HeartRateCard';
import Waveform from './components/Waveform';
import SignalQuality from './components/SignalQuality';
import RecordingPanel from './components/RecordingPanel';
import Spectrum from './components/Spectrum';
import DeviceStatus from './components/DeviceStatus';
import SafetyNotice from './components/SafetyNotice';
import { getDeviceStatus, getHealth } from './services/api';
import { SampleRingBuffer, createAudioSocket } from './services/websocket';

const NAV = [
  { id: 'live', label: 'Live Monitor' },
  { id: 'recordings', label: 'Recordings' },
  { id: 'analysis', label: 'Signal Analysis' },
  { id: 'settings', label: 'Settings' },
];

function formatDuration(sec) {
  const s = Math.max(0, Math.floor(sec));
  const m = Math.floor(s / 60);
  const r = s % 60;
  return `${String(m).padStart(2, '0')}:${String(r).padStart(2, '0')}`;
}

export default function App() {
  const [theme, setTheme] = useState(() => localStorage.getItem('cs-theme') || 'light');
  const [page, setPage] = useState('live');
  const [backendOnline, setBackendOnline] = useState(false);
  const [error, setError] = useState('');
  const [deviceIp, setDeviceIp] = useState(() => localStorage.getItem('cs-esp-ip') || '');
  const [status, setStatus] = useState({});
  const [bpm, setBpm] = useState(null);
  const [quality, setQuality] = useState('No Signal');
  const [rms, setRms] = useState(0);
  const [peak, setPeak] = useState(0);
  const [sampleRate, setSampleRate] = useState(4000);
  const [paused, setPaused] = useState(false);
  const [autoScale, setAutoScale] = useState(true);
  const [windowSec, setWindowSec] = useState(2);
  const [isRecording, setIsRecording] = useState(false);
  const [sessionStart, setSessionStart] = useState(Date.now());
  const [now, setNow] = useState(Date.now());
  const [spectrum, setSpectrum] = useState({ freqs: [], magnitude: [] });
  const [canvasTick, setCanvasTick] = useState(0);

  const ringRef = useRef(new SampleRingBuffer(12000));
  const recordRef = useRef([]);
  const socketRef = useRef(null);
  const pausedRef = useRef(false);

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('cs-theme', theme);
  }, [theme]);

  useEffect(() => {
    pausedRef.current = paused;
  }, [paused]);

  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, []);

  const handleMessage = useCallback((msg) => {
    if (!msg || typeof msg !== 'object') return;
    if (msg.type === 'audio') {
      if (!pausedRef.current) {
        ringRef.current.push(msg.samples);
        setCanvasTick((n) => n + 1);
      }
      if (recordRef.current && Array.isArray(recordRef.current) && recordRef.current.__active) {
        recordRef.current.push(...msg.samples);
      }
      setBpm(msg.bpm);
      setQuality(msg.signal_quality || 'No Signal');
      setRms(msg.rms || 0);
      setPeak(msg.peak || 0);
      setSampleRate(msg.sample_rate || 4000);
      setStatus((prev) => ({
        ...prev,
        connected: true,
        packets_received: msg.packets_received ?? prev.packets_received,
        sample_rate: msg.sample_rate || prev.sample_rate,
        bpm: msg.bpm,
        signal_quality: msg.signal_quality,
      }));
      setError('');
    } else if (msg.type === 'device_status') {
      setStatus(msg.data || {});
    } else if (msg.type === 'spectrum') {
      setSpectrum(msg.data || { freqs: [], magnitude: [] });
    } else if (msg.type === 'error') {
      setError(msg.message || 'WebSocket error');
    }
  }, []);

  const connectBackend = useCallback(() => {
    if (typeof WebSocket === 'undefined') {
      setError('Browser does not support WebSocket APIs.');
      return;
    }
    socketRef.current?.disconnect();
    const sock = createAudioSocket({
      onOpen: () => {
        setBackendOnline(true);
        setError('');
        setSessionStart(Date.now());
      },
      onClose: () => setBackendOnline(false),
      onError: (err) => setError(err.message || 'WebSocket disconnected'),
      onMessage: handleMessage,
    });
    socketRef.current = sock;
    sock.connect();
  }, [handleMessage]);

  const disconnectBackend = useCallback(() => {
    socketRef.current?.disconnect();
    socketRef.current = null;
    setBackendOnline(false);
  }, []);

  useEffect(() => {
    connectBackend();
    getHealth().catch(() => setError('Backend unavailable. Start the FastAPI server on port 8000.'));
    getDeviceStatus()
      .then((d) => setStatus(d))
      .catch(() => {});
    return () => disconnectBackend();
  }, [connectBackend, disconnectBackend]);

  useEffect(() => {
    if (!backendOnline) return undefined;
    const id = setInterval(() => socketRef.current?.requestSpectrum(), 1500);
    return () => clearInterval(id);
  }, [backendOnline]);

  const getSamples = useCallback(() => {
    // canvasTick dependency forces refresh binding when data arrives
    void canvasTick;
    return ringRef.current.toArray();
  }, [canvasTick]);

  const deviceOnline = Boolean(status.connected) && backendOnline && (status.packets_received || 0) > 0;

  const startRecording = () => {
    recordRef.current = [];
    recordRef.current.__active = true;
    setIsRecording(true);
  };

  const stopRecordingFlag = () => {
    if (recordRef.current) recordRef.current.__active = false;
    setIsRecording(false);
  };

  const getRecordedSamples = () => {
    const arr = recordRef.current || [];
    return Array.from(arr);
  };

  const sessionDuration = formatDuration((now - sessionStart) / 1000);

  const settingsPanel = useMemo(
    () => (
      <div className="panel layout-stack">
        <h3>Settings</h3>
        <label className="row">
          <span>Waveform window (seconds)</span>
          <input
            type="text"
            value={String(windowSec)}
            onChange={(e) => {
              const v = Number(e.target.value);
              if (Number.isFinite(v) && v >= 0.5 && v <= 10) setWindowSec(v);
            }}
            aria-label="Waveform time window"
          />
        </label>
        <label className="row">
          <input type="checkbox" checked={autoScale} onChange={(e) => setAutoScale(e.target.checked)} />
          Auto-scale amplitude
        </label>
        <p className="muted">
          Firmware ADC pin / sample rate are configured on the ESP32 (`ADC_PIN`, `SAMPLE_RATE`).
          Saved ESP32 IP is for reference/debugging only: <strong>{deviceIp || 'not set'}</strong>
        </p>
      </div>
    ),
    [autoScale, deviceIp, windowSec],
  );

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <h1>CardioSense</h1>
          <p>IoT Digital Stethoscope</p>
        </div>
        <nav className="nav" aria-label="Primary">
          {NAV.map((item) => (
            <button
              key={item.id}
              type="button"
              className={page === item.id ? 'active' : ''}
              onClick={() => setPage(item.id)}
            >
              {item.label}
            </button>
          ))}
        </nav>
        <div className="sidebar-foot">
          Educational prototype for learning IoT, DSP, and embedded systems.
          Not a medical device.
        </div>
      </aside>

      <main className="main">
        <SafetyNotice />
        <Header
          title="Heart Sound Monitor"
          subtitle="ESP32 connection status and live phonocardiogram"
          theme={theme}
          onToggleTheme={() => setTheme((t) => (t === 'dark' ? 'light' : 'dark'))}
          connectionLabel={deviceOnline ? 'ESP32 streaming' : backendOnline ? 'Backend only' : 'Disconnected'}
          online={backendOnline}
        />

        {(page === 'live' || page === 'settings') && (
          <DeviceConnection
            backendOnline={backendOnline}
            deviceOnline={deviceOnline}
            deviceIp={deviceIp}
            onConnectBackend={connectBackend}
            onDisconnectBackend={disconnectBackend}
            onSetDeviceIp={(ip) => {
              setDeviceIp(ip);
              localStorage.setItem('cs-esp-ip', ip);
            }}
            error={error}
          />
        )}

        {page === 'live' && (
          <>
            <div className="grid-metrics">
              <HeartRateCard bpm={bpm} status={bpm ? 'ok' : 'insufficient_signal'} />
              <SignalQuality quality={quality} rms={rms} peak={peak} />
              <div className="panel metric-card">
                <h3>Signal Peak</h3>
                <p className="value">{Number(peak || 0).toFixed(0)}</p>
                <p className="hint">Normalized ADC amplitude units</p>
              </div>
              <div className="panel metric-card">
                <h3>Session Duration</h3>
                <p className="value" style={{ fontSize: '1.6rem' }}>{sessionDuration}</p>
                <p className="hint">Since last backend connect</p>
              </div>
            </div>

            <div className="panel">
              <div className="toolbar">
                <h3 style={{ margin: 0, flex: 1 }}>Live Phonocardiogram</h3>
                <button type="button" className="btn btn-secondary" onClick={() => setPaused((p) => !p)}>
                  {paused ? 'Resume' : 'Pause'}
                </button>
                <button
                  type="button"
                  className="btn btn-secondary"
                  onClick={() => {
                    ringRef.current.clear();
                    setCanvasTick((n) => n + 1);
                  }}
                >
                  Clear
                </button>
              </div>
              <Waveform
                getSamples={getSamples}
                paused={paused}
                sampleRate={sampleRate}
                windowSec={windowSec}
                autoScale={autoScale}
              />
            </div>

            <div className="layout-2">
              <Spectrum freqs={spectrum.freqs} magnitude={spectrum.magnitude} />
              <DeviceStatus status={status} />
            </div>

            <RecordingPanel
              isRecording={isRecording}
              onStart={startRecording}
              onStop={stopRecordingFlag}
              getRecordedSamples={getRecordedSamples}
              sampleRate={sampleRate}
              deviceId={status.device_id}
              bpm={bpm}
              quality={quality}
            />
          </>
        )}

        {page === 'recordings' && (
          <RecordingPanel
            isRecording={isRecording}
            onStart={startRecording}
            onStop={stopRecordingFlag}
            getRecordedSamples={getRecordedSamples}
            sampleRate={sampleRate}
            deviceId={status.device_id}
            bpm={bpm}
            quality={quality}
          />
        )}

        {page === 'analysis' && (
          <div className="layout-stack">
            <Spectrum freqs={spectrum.freqs} magnitude={spectrum.magnitude} />
            <div className="panel">
              <h3>Signal Analysis</h3>
              <p className="muted">
                Metrics are derived from received samples (RMS, peak, band energy, envelope peaks).
                BPM is a prototype estimate – not clinically validated. Insufficient quality shows -- BPM.
              </p>
              <div className="kv">
                <span>Quality</span>
                <strong>{quality}</strong>
                <span>RMS</span>
                <strong>{Number(rms).toFixed(2)}</strong>
                <span>Peak</span>
                <strong>{Number(peak).toFixed(2)}</strong>
                <span>BPM</span>
                <strong>{Number.isFinite(bpm) && bpm > 0 ? Math.round(bpm) : '--'}</strong>
              </div>
            </div>
          </div>
        )}

        {page === 'settings' && settingsPanel}
      </main>
    </div>
  );
}
